// Ejercicio1.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//
//Librerias
#include <iostream>
#include <string>
#include <Windows.h>
#include <cstdlib>
#include <conio.h>
#include <MMSystem.h>
#include <time.h>

using namespace std;

//Atributos enemigo
int enemyHP = 200;
string enemyName = "Jorge";
bool enemyIsAlive = true;
int enemyDMG;

//Atributos enemigo 2
int enemy2HP = 150;
string enemy2Name = "Carmen";
bool enemy2IsAlive = true;
int enemy2DMG;

//Atributos del personaje
int heroHP = 120;
int heroDMG;
string heroName;
bool heroIsAlive = true;

//Otros
int respuesta;
int enemyRand;
int espada = 50;
int magia = 35;
int punetazo = 40;
int tipoDMG;
int tipoDMG2;
int espadautilizable = 3;
int enemyChoosed;



void empezarElJuego() {
    cout << "Los enemigos " << enemyName << " y " << enemy2Name << " han aparecido\n";
    cout << "Como se llama el heroe?\n";
    cin >> heroName;
    cout << "El nombre de tu heroe es " << heroName << "\n";
}

bool heroAlive() {
    if (heroHP <= 0) {
        cout << "GameOver";
        heroHP = 0;
        //heroIsAlive = false;
        //PlaySound(TEXT("Game_over_sonido.wav"), NULL, SND_FILENAME | SND_ASYNC);
        return false;

    }
    else {
        return true;
    }
}

void enemigoDMG(int& enemyDMG, string& enemyName) {
    enemyDMG = 10 + rand() % (10 - 20);
    heroHP = heroHP - enemyDMG;
    cout << "\n";
    cout << "El enemigo " << enemyName << " te ha atacado y te ha hecho " << enemyDMG << " de daño\n";
    cout << "\n";
    cout << "Ahora tu vida ahora es de " << heroHP << "\n";
}



void tipoATQ() {
    cout << "\n";
    cout << "[1] Espada (Se puede utilizar 3 veces)\n";
    cout << "[2] Magia\n";
    cout << "[3] Punetazo \n";
    cin >> tipoDMG;
    switch (tipoDMG) {
    case  1:
        if (espadautilizable == 0) {
            cout << "\n";
            cout << "Este ataque no se puede utilizar mas, que ataque quieres escoger\n";
            cout << "[2] Magia\n";
            cout << "[3] Punetazo \n";
            cin >> tipoDMG2;
            espadautilizable = 0;
            if (tipoDMG2 == 2) {
                heroDMG = magia;
            }
            else if (tipoDMG2 == 3) {
                heroDMG = punetazo;
            }
        }
        heroDMG = espada;
        espadautilizable = espadautilizable - 1;

        break;
    case  2:
        heroDMG = magia;
        break; 
    case  3:
        heroDMG = punetazo;
    }
    cout << "\n";
    cout << "El DMG de tu personaje es " << heroDMG << "\n";
}

int chooseEnemy() {
    respuesta = 0;
    while (respuesta != 1 && respuesta != 2) {

        cout << "A que enemigo quieres atacar ([1] Jorge) o ([2] Carmen)?";
        cin >> respuesta;
        if (respuesta != 1 && respuesta != 2) {
            cout << "Este enemigo no existe, prueba otra vez\n";
        }
    }
    return respuesta;

}


void siEnemymenoriguala0(string& enemyName, int& enemyHP, bool& enemyIsAlive) {
    cout << "\n";
    cout << "Has humillado a " << enemyName << "\n";
    enemyHP = 0;
    enemyIsAlive = false;
}


void siEnemysuperiora0(string& enemyName, int& enemyHP) {
    cout << "\n";
    cout << "EL enemigo " << enemyName << " ahora tiene " << enemyHP << " HP\n";
}
void siestamuerto(string& enemyName) {
    cout << "\n";
    cout << "El enemigo " << enemyName << " ya esta muerto\n";
}
void elegirENEMY() {


    enemyChoosed = chooseEnemy();

    if ((enemyChoosed == 1) && (enemyIsAlive == true)) {

        enemyHP = enemyHP - heroDMG;
        if (enemyHP <= 0) {
            siEnemymenoriguala0(enemyName, enemyHP, enemyIsAlive);
        }
        else {
            siEnemysuperiora0(enemyName, enemyHP);
        }
    }
    else if (!enemyIsAlive) {
        siestamuerto(enemyName);
    }

    if ((enemyChoosed == 2) && (enemy2IsAlive == true)) {

        enemy2HP = enemy2HP - heroDMG;
        if (enemy2HP <= 0) {
            siEnemymenoriguala0(enemy2Name, enemy2HP, enemy2IsAlive);
        }
        else {
            siEnemysuperiora0(enemy2Name, enemy2HP);;
        }
    }
    else  if (!enemy2IsAlive) {
        siestamuerto(enemy2Name);;
    }
}


void ATQenemy() {
    if (enemyIsAlive && enemy2IsAlive) {
        enemyRand = rand() % 2;
        switch (enemyRand) {
        case (0):
            enemigoDMG(enemyDMG, enemyName);

            break;
        case (1):
            enemigoDMG(enemy2DMG, enemy2Name);
            break;
        }
    }
    else if (enemyIsAlive == false) {
        enemigoDMG( enemyDMG, enemyName);
    }
    else if (enemy2IsAlive == false) {
        enemigoDMG(enemy2DMG, enemy2Name);
    }

}





int main() {



    empezarElJuego();
    cout << "Cual quieres que sea tu tipo de DMG?\n";
    srand(time(NULL));



    while ((enemyIsAlive || enemy2IsAlive) && (heroIsAlive)) {

        tipoATQ();

        elegirENEMY();

        ATQenemy();

        heroIsAlive = heroAlive();
    }
}
